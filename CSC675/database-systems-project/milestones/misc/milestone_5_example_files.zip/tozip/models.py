# from database_old import Database
from database import Database

class UserExample:
    def __init__(self, user_id, username, about_me) -> None:
        self.id = user_id
        self.username = username
        self.about_me = about_me
    
    # One of the nice things about static methods is that you can call this method
    # without needing to create an object
    # You call User.get_user_by_username(username) statically, and it returns an instantiated object of class User
    @staticmethod
    def get_user_by_username(username) -> 'UserExample':
        # Prepare the query and get data
        db = Database()
        connection = db.connect()
        query = "SELECT * FROM UserExample WHERE UserExample.username = %s"
        values = (username)
        response = db.select(query, values)
        
        # Initialize the model and return it
        # TODO: You probably want to check if the user actually exists
        user_id = response["id"]
        user_username = response["username"]
        user_about_me = response["about_me"]
        user_model = UserExample(user_id, user_username, user_about_me)

        # Close the connection to prevent a memory leak
        connection.close()

        return user_model
    