
# "Oracle" function -- assume exists to show contradiction
#
import Mod2InMod3Out 
import utils
from utils import rf

from universal import universal

# Complete for the final exam by filling in the ellipses
def alterYesToMod(inString):
   . . .
   result = universal(progString,newInString)
   . . .
        

# Complete for the final exam by filling in the ellipses. For the
# call to mod2InMod3Out, supply a 2nd argument if needed.
def yesViaMod(progString,inString):
    ...
    result = mod2InMod3Out((rf('alterYesToMod.py'),...)
    ...



'''
Mod2InMod3Out is undecidable because ...


'''
