from graph import Graph

'''
In an instance of PairNodeCover has the syntax
I = G;N

where 

G is an undirected, unweighted graph defind as a sequence of edges (for
example: 'a,b a,c c,d' )
 
I is a positive instance of Pair NodeCover is there is a subset S of the
nodes of G, |S| <= 2, such that every edge in G has a an endpoint in
S. For example, 'a,b a,c c,d' is a positive instance of PairodeCover,
because every edge in the graph has an endpoint in {a,c}, and
|{a,c}| = 2; 'a,b a,c' is also a positive instance of PairNodeCover because
every edge in the graph has an endpoint in {a}. 'a,b a,c d,e f,g' is a
negative instance of PairNodeCover

 '''

DEV = True
VERBOSE = True

def vfyPairNodeCover(I,S,H):
    edges = I.split()
    g = Graph(I, directed=False,weighted=False)
    nodes = list(g.nodes.keys())
    node_cover = H.split()
    n = len(node_cover)

    ##### Midterm #2 Complete the verifier, returning 'unsure' as needed

    return 'correct'

if __name__ == '__main__':

    def test_case(func,I,S,H,expected,num,comment=''):
        err = '** '
        result = func(I,S,H)
        func_name = str(func).split()[1]
        func_call = f'''{func_name}("{I}","{S}","{H}")'''
        if result == expected: err = ''
        e = expected
        print (f'{err}test #{num} {func_call}: expected "{e}", received "{result}"')
        print (f'test #{num} Explanation: {comment}\n')
        return num + 1

    
    F = vfyPairNodeCover
    I = 'a,b  a,c b,c'
    num = 1
    exp = '|{a,b}| = 2'
    num = test_case(F,I,'yes','a b','correct',num,exp)

    I = 'a,b  a,c b,c'
    exp = '{a} does not cover graph'
    num = test_case(F,I,'yes','a','unsure',num,exp)

    I = 'a,b  a,c a,d a,e'
    exp = '{a} covers graph'
    num = test_case(F,I,'yes','a','correct',num,exp)

    I = 'a,b  a,c b,c c,d'
    exp = 'Nodes {a,b} do not cover edge c,d'
    num = test_case(F,I,'yes','a b','unsure',num,exp)

    I = 'a,b  c,d e,f'
    exp = '|{a,c e}| > 2'
    num = test_case(F,I,'yes','a c e','unsure',num,exp)
    
    
