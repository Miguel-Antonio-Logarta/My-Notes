import java.util.Scanner;

public class RestaurantCheckManager {
    public static void main(String[] args) {

    }
}
