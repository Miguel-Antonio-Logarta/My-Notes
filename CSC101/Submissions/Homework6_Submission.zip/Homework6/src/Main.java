//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        String[] lines = {
            "Moe: I find it hilarious that on one side of the world they sip on water with leaves, while on this side of the globe, we chug bean water.",
            "Rebecca: Bean water? Did you mean coffee?",
            "Moe: I'm calling what it truly is. It's funny how we can extract so much essence from just pressing water through grounded coffee beans.",
            "Rebecca: Not to mention it has complex flavours and the fact that it'll always be there for you even during the worst mornings.",
            "Moe: But don't underestimate leaf water either. The Chinese really love tea.",
            "Rebecca: We should really make a club to exploring both. I'll call it the 'Brotherhood of Bean Water and Tea Leaf.'",
            "Moe: Great idea!"
        };

        for (String line : lines) {
            System.out.println(line);
        }
    }
}