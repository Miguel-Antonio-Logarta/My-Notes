// Class to allow simulation to return multiple values all at once
public class SimulationData {
	public double height;
	public double time;
	public double velocity;
	public double gravity;
	public double timeStep;
}
