public class Plant extends Organism {
    Plant(String speciesName, String commonName, String individualName, int nutritionLevel) {
        super(speciesName, commonName, individualName, nutritionLevel);
    }
}
