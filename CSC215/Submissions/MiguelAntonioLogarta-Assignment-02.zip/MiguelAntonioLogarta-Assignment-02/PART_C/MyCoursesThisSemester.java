 /****************************************************************
 *
 * File: MyCoursesThisSemester.java
 * By:   Miguel Antonio Logarta
 * Date: 09-04-2024
 *
 * Description: This is a file that tests if the Apache NetBeans
 * IDE is working. It prints out all the courses I am taking for this semester
 *
 ****************************************************************/

package com.mycompany.mycoursesthissemester;

/**
 *
 * @author potatochipse
 */
public class MyCoursesThisSemester {

    public static void main(String[] args) {
        System.out.println("Hello World!");        
        System.out.println("These are the courses I am taking this semseter!");
        
        System.out.println("CSC 215 Intermediate Computer Science Lecture");
        System.out.println("CSC 215 Intermediate Computer Science Seminar");
        System.out.println("CSC 648 Software Development");
        System.out.println("CSC 300GW Ethics, Communication, and Tools for Software Development");
        System.out.println("MATH 425 Applied Linear Algebra");
        System.out.println("CSC 671 Deep Learning");
    }
}
